/** 
   Copyright (c) 2011 Carsten Moeller, Pinneberg, Germany. <info@osm2po.de>

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as 
   published by the Free Software Foundation, either version 3 of the 
   License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package de.cm.osm2po.plugins;

import java.io.BufferedInputStream;
import java.io.InputStream;

import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;

import de.cm.osm2po.Config;
import de.cm.osm2po.converter.OsmParserHandler;
import de.cm.osm2po.converter.OsmXmlParser;

public class OsmBz2Parser extends OsmXmlParser {

    /** {@inheritDoc} */
    @Override
    public void open(InputStream bz2InputStream,
            OsmParserHandler processor, Config config) {
        try {
            BZip2CompressorInputStream is = new BZip2CompressorInputStream(
                    new BufferedInputStream(bz2InputStream));
            super.open(is, processor, config);
            
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
}
